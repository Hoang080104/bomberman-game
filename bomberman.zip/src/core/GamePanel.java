package core;

import entities.Bomber;
import tiles.Tile;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
    private GameMap gameMap;
    private Bomber bomber;
    private Timer timer;

    public GamePanel() {
        setPreferredSize(new Dimension(Tile.TILE_SIZE * 31, Tile.TILE_SIZE * 13)); // 992 x 416
        setFocusable(true);
        addKeyListener(this);

        gameMap = new GameMap(31, 13);
        bomber = new Bomber(1 * Tile.TILE_SIZE, 1 * Tile.TILE_SIZE, gameMap);

        MapLoader.loadMap("level1.txt", gameMap, bomber);

        timer = new Timer(1000 / 60, this);  // 60 FPS
        timer.start();

        // Cần để đảm bảo JPanel nhận phím
        requestFocusInWindow();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        gameMap.render(g);
        bomber.render(g);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Không update bomber tại đây nữa nếu dùng từng bước
        gameMap.update();
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        bomber.handleKeyPressed(e);
        repaint(); // Đảm bảo vẽ lại ngay khi có hành động
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Không sử dụng
    }
}
