package entities;

import core.GameMap;
import tiles.*;

import java.awt.*;
import java.awt.event.KeyEvent;

public class Bomber extends MovableGameObject {
    private final int speed = Tile.TILE_SIZE;
    private boolean alive = true;

    public Bomber(int x, int y, GameMap gameMap) {
        super(x, y, gameMap);
    }

    public boolean isAlive() {
        return alive;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void update() {
        if (!alive) return;

        // Kiểm tra va chạm với enemy
        for (Enemy enemy : gameMap.getEnemies()) {
            if (enemy.isAlive() && enemy.getX() == x && enemy.getY() == y) {
                alive = false;
                System.out.println("Game Over: Bomber bị enemy chạm");
                return;
            }
        }

        // Kiểm tra đứng trong phạm vi bom nổ
        for (Bomb bomb : gameMap.getBombs()) {
            if (bomb.isExploded()) {
                int bx = bomb.getX() / Tile.TILE_SIZE;
                int by = bomb.getY() / Tile.TILE_SIZE;
                int px = x / Tile.TILE_SIZE;
                int py = y / Tile.TILE_SIZE;

                if ((bx == px && Math.abs(by - py) <= 1) || (by == py && Math.abs(bx - px) <= 1)) {
                    alive = false;
                    System.out.println("Game Over: Bomber bị nổ");
                    return;
                }
            }
        }
    }

    @Override
    public void render(Graphics g) {
        if (!alive) return;
        g.setColor(Color.BLUE);
        g.fillOval(x, y, Tile.TILE_SIZE, Tile.TILE_SIZE);
    }

    private boolean canMoveTo(int newX, int newY) {
        int tileX1 = newX / Tile.TILE_SIZE;
        int tileY1 = newY / Tile.TILE_SIZE;
        int tileX2 = (newX + Tile.TILE_SIZE - 1) / Tile.TILE_SIZE;
        int tileY2 = (newY + Tile.TILE_SIZE - 1) / Tile.TILE_SIZE;

        // Kiểm tra grass và không có bomb tại vị trí đó
        if (!(gameMap.isGrassTile(tileX1, tileY1) &&
                gameMap.isGrassTile(tileX2, tileY1) &&
                gameMap.isGrassTile(tileX1, tileY2) &&
                gameMap.isGrassTile(tileX2, tileY2))) {
            return false;
        }

        // Không di chuyển vào ô có bom chưa nổ
        int cx = newX / Tile.TILE_SIZE;
        int cy = newY / Tile.TILE_SIZE;
        for (Bomb bomb : gameMap.getBombs()) {
            int bx = bomb.getX() / Tile.TILE_SIZE;
            int by = bomb.getY() / Tile.TILE_SIZE;
            if (!bomb.isExploded() && bx == cx && by == cy) {
                return false;
            }
        }

        return true;
    }

    public void handleKeyPressed(KeyEvent e) {
        if (!alive) return;

        int newX = x, newY = y;
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> newY -= speed;
            case KeyEvent.VK_DOWN -> newY += speed;
            case KeyEvent.VK_LEFT -> newX -= speed;
            case KeyEvent.VK_RIGHT -> newX += speed;
            case KeyEvent.VK_SPACE -> placeBomb();
            default -> {
                return;
            }
        }

        if (canMoveTo(newX, newY)) {
            x = newX;
            y = newY;
        }
    }

    public void handleKeyReleased(KeyEvent e) {}

    private void placeBomb() {
        Bomb bomb = new Bomb(x, y, gameMap);
        gameMap.addBomb(bomb);
    }
}
