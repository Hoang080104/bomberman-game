package entities;

import core.GameMap;

import java.awt.*;

public class Oneal extends Enemy {
    private GameMap map;

    public Oneal(int x, int y, GameMap map) {
        super(x, y, map);
        this.map = map;
    }

    @Override
    public void update() {
        move();
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.RED);
        g.fillOval(x * 32, y * 32, 32, 32);
    }

    private void move() {
        // Dummy AI: chỉ di chuyển sang phải nếu là grass
        if (map.isGrassTile(x + 1, y)) {
            x++;
        }
    }
}
