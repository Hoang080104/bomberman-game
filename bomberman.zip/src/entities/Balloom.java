package entities;

import core.GameMap;

import java.awt.*;

public class Balloom extends Enemy {
    private GameMap map;

    public Balloom(int x, int y, GameMap map) {
        super(x, y, map);
        this.map = map;
    }

    @Override
    public void update() {
        move();
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.PINK);
        g.fillOval(x * 32, y * 32, 32, 32);
    }

    private void move() {
        // Dummy AI: chỉ di chuyển xuống nếu là grass
        if (map.isGrassTile(x, y + 1)) {
            y++;
        }
    }
}
