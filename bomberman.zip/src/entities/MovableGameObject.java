package entities;

import core.GameMap;
import java.awt.*;

public abstract class MovableGameObject extends GameObject {
    protected GameMap gameMap;

    public MovableGameObject(int x, int y, GameMap gameMap) {
        super(x, y);
        this.gameMap = gameMap;
    }

    public abstract void update();
}
