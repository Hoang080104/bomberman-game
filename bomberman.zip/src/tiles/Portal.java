package tiles;

import java.awt.*;

public class Portal extends Tile {
    private boolean visible = false;

    public Portal(int x, int y) {
        super(x, y);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isVisible() {
        return visible;
    }

    @Override
    public void render(Graphics g) {
        if (isVisible()) {
            g.setColor(new Color(255, 105, 180));
            g.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
        }
    }

    @Override
    public boolean isPassable() {
        return visible;
    }
}
